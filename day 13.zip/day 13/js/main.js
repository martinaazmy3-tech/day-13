
//array
let students = [
    {
        id: 1,
        name: "Mostafa Mohamed",
        age: 28,
        city: "Cairo",
        grade: 95,
        isGraduated: true,
        skills: ["HTML", "CSS", "JS"]
    },
    {
        id: 2,
        name: "Ali Hassan",
        age: 17,
        city: "Alex",
        grade: 60,
        isGraduated: false,
        skills: ["HTML"]
    },
    {
        id: 3,
        name: "Sara Ali",
        age: 24,
        city: "Mansoura",
        grade: 88,
        isGraduated: true,
        skills: ["HTML", "CSS", "JS", "React"]
    }
];


//عدد الطلاب 
console.log(students.length);


//اول اسم 
console.log(students[0].name);


//اخر اسم 
console.log(students[2].name);


// الاسماء ب loop استخدمت for 
for (let i =0; i <= 2; i++ )
{console.log(students[i].name)}


 //اطبع كل الطلاب ببياناتهم 
 for (let i =0; i <= 2; i++ ){
console.log("name : " + students[i].name);
console.log("age : " + students[i].age);
console.log("city : " + students[i].city);
console.log("grade : " + students[i].grade);
 }


 //سنهم اكبر من 18
 //استخدمت if للشرط 

for (let i =0; i <= 2; i++ ){
 if (students[i].age >18)
    {console.log(students[i].name)}
}


//درجتهم اكتر من 90 نفس فكره الشرط اللي قبليها 
for (let i =0; i <= 2; i++ ){
 if (students[i].grade >90)
    {console.log(students[i].name)}
}


//الخرييجين 
for (let i =0; i <= 2; i++ ){
 if (students[i].isGraduated)
    {console.log(students[i].name)}
}


//مجموع كل الطلبه
let total = 0;
for (let i =0; i <= 2; i++ ){
    total  = total + students[i].grade;
}
console.log(total );


//متوسط الدرجات 
let average =0;
{
average = total / students.length;
}
console.log(average );


//اعلي درجه
let highgrade = students[0].grade;
for (let i =0; i <= 2; i++ ){
if(students[i].grade>highgrade)
highgrade = students[i].grade;
console.log(highgrade)
}


//اق درجه

let lowgrade = students[0].grade; 
for (let i =0; i <= 2; i++ ){
if(students[i].grade<lowgrade)
lowgrade = students[i].grade;
console.log(lowgrade)
}


//بالابجديه 
students.sort(function(a, b) {
    return a.name.localeCompare(b.name);
});

for (let i = 0;  i<=2; i++) {
    console.log(students[i].name);
}
//الاسماء بالعكس
for (let i =2; i >= 0; i-- )
{console.log(students[i].name)}


//عددالحروف في الاسم 
//الحرف الاول والاخير 
for (let i = 0; i <= 2; i++) {
console.log(students[i].name.length);//عدد الحروف 
console.log(students[i].name[0]);//اول حرف 
console.log(students[i].name[students[i].name.length - 1]); // -1 length بتجيب عدد الحروف كاملين وعندنا بنبدا ب 0 

}
//الاسم كبتل استخدمتtoUpperCase

for (let i =0; i<=2; i++) {
    console.log(students[i].name.toUpperCase());
}


//الاسم سمول استخدمت toLocaleLowerCase
for (let i =0; i<=2; i++) {
    console.log(students[i].name.toLocaleLowerCase());
}


//اسم علي 
for (let i = 0; i <= 2; i++) {
    if (students[i].name.toLowerCase().includes("ali")) {// includes عشان يطبع اي اسم فيه علي 
  console.log(students[i].name);
    }

}

//اقسم الاسمين ب split

for (let i =0; i<=2; i++) {
   let name=(students[i].name.split(" "));
   console.log(name[0]);
    console.log(name[1]);
}

//اعمل join
for (let i =0; i<=2; i++) {
  let name = students[i].name.split(" ");
    console.log(name.join(" "));
   
}

//اشيل المسافات 


for (let i =0; i<=2; i++) {
    console.log(students[i].name.trim());
}


//عدد الاسكيلز 
for (let i =0; i <= 2; i++ ){
        {console.log(students[i].skills.length)}
}


//الاسكيلز 
for (let i =0; i <= 2; i++ ){
        {console.log(students[i].skills)}
}


//ضيف اسكيلز 
for (let i = 0; i<= 2; i++) {
    students[i].skills.push("Python");
    console.log(students[i].skills);
}

// حذف اخر اسكيلز 
for (let i = 0; i<= 2; i++) {
    students[i].skills.pop();
    console.log(students[i].skills);
}


// js 

for (let i = 0; i<= 2; i++) {

    if (students[i].skills.includes("JS")) {
        console.log(students[i].name);
    }
}



//عكس ترتيب ااسكيز

for (let i =2; i >= 0; i-- )
{console.log(students[i].skills)}


// الاسكيلز بالابجديه 

students.sort(function(a, b) {
    return a.name.localeCompare(b.skills);
});
for (let i = 0;  i<=2; i++) {
    console.log(students[i].skills);
}


//حول الاسكيلز لسترينج 
for (let i = 0; i <= 2; i++) {
    console.log(students[i].skills.join(","));
}


//اطبع كل keys 
for (let i = 0; i <= 2; i++) {
console.log(Object.keys(students[i]));
}


//values اطبع كل 

for (let i = 0; i <= 2; i++) {
console.log(Object.values(students[i]));
}



// key,values
for (let i = 0; i <= 2; i++) {
console.log(Object.entries(students[i]));
}

// اضيف country
